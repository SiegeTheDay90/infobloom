import './eventHandlers/auth-attachments.js';
import './eventHandlers/data-attachments.js';

// import { seedUsers } from './firebase/seed.js';

// seedUsers(20);