// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

const firebaseConfig = {
  apiKey: "AIzaSyBQvBOqX2N1fCHKpqMDxcg_MzeCDYaSWu8",
  authDomain: "infobloom-90812.firebaseapp.com",
  projectId: "infobloom-90812",
  storageBucket: "infobloom-90812.firebasestorage.app",
  messagingSenderId: "693086852025",
  appId: "1:693086852025:web:426fa7563a4d9658451c68",
  measurementId: "G-QHL340PM27"
};

export default firebaseConfig;